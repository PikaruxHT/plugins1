﻿var fetch = global.nodemodule["node-fetch"];

var HD_get = function HD_get(type, data) {
	(async function () {
		var returntext = `Donate để mình có kinh phí duy trì bot (không bắt buộc), cảm ơn.\nTên: NGUYEN VAN BANG\nMomo: 0392244286\nVietinbank: 106870139683`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	HD_get: HD_get
}