﻿var fetch = global.nodemodule["node-fetch"];

var HD_get = function HD_get(type, data) {
	(async function () {
		var returntext = ` Agribank 
Lê Hoài Linh
7002205163830
Momo & Tsr: 0901942184`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	HD_get: HD_get
}